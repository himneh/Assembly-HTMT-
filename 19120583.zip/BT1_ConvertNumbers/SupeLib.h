#pragma once
#include <iostream>
#include <vector>
#include <string>
#include <math.h>
using namespace std;

int ConvertDECtoBIN(int k);

vector<char> ConvertDECtoHEX(int k);

int ConvertNums(int k, int q);

int ConvertHEXtoDEC(string s);

string ConvertBINtoHEX(string s);